import { SignupsupplierComponent } from './signupsupplier.component'

describe('SignupsupplierComponent', () => {
  it('should mount', () => {
    cy.mount(SignupsupplierComponent)
  })
})