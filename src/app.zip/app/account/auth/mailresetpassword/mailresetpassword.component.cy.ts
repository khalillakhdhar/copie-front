import { MailresetpasswordComponent } from './mailresetpassword.component'

describe('MailresetpasswordComponent', () => {
  it('should mount', () => {
    cy.mount(MailresetpasswordComponent)
  })
})