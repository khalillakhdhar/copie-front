import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/shared/services/user.service';

@Component({
  selector: 'app-login-admin',
  templateUrl: './login-admin.component.html',
  styleUrl: './login-admin.component.css'
})
export class LoginAdminComponent implements OnInit {
  adminLoginForm!: FormGroup;
  submitted = false;
  error: string = '';

  constructor(private fb: FormBuilder, private authService: UserService, 
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.adminLoginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  get f() { return this.adminLoginForm.controls; }

  onSubmit(): void {
    this.submitted = true;

    if (this.adminLoginForm.invalid) return;

    this.authService.login(this.adminLoginForm.value).subscribe({
      next: () => {
        const roles = JSON.parse(localStorage.getItem('roles') || '[]');

        if (roles.includes('Administrateur')) {
          this.router.navigate(['/admin/dashboard']);
        } 
        else {
          this.error = 'Accès non autorisé pour cet espace.';
          this.authService.logout();
          this.router.navigate(['/auth/login']); 
        }
      },
      error: (err) => {
        alert("Erreur d'authentification : " + err.error);
    }
    });
  }
}