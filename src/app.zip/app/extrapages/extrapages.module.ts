import { NgModule } from '@angular/core';

import { ExtrapagesRoutingModule } from './extrapages-routing.module';

@NgModule({
  declarations: [],
  imports: [
    ExtrapagesRoutingModule,
  ]
})
export class ExtrapagesModule { }
