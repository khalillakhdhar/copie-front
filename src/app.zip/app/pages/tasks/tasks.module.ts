import { NgModule } from '@angular/core';
import { TasksRoutingModule } from './tasks-routing.module';


@NgModule({
  declarations: [],
  imports: [
    TasksRoutingModule,
  ]
})
export class TasksModule { }
