import { Component, ElementRef, OnInit } from '@angular/core';




@Component({
  selector: 'app-chartist',
  templateUrl: './chartist.component.html',
  styleUrls: ['./chartist.component.scss']
})

/**
 * Chartist-chart component
 */
export class ChartistComponent  {
 
}