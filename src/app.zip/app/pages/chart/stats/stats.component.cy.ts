import { StatsComponent } from './stats.component'

describe('StatsComponent', () => {
  it('should mount', () => {
    cy.mount(StatsComponent)
  })
})