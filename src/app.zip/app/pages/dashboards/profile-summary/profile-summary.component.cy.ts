import { ProfileSummaryComponent } from './profile-summary.component'

describe('ProfileSummaryComponent', () => {
  it('should mount', () => {
    cy.mount(ProfileSummaryComponent)
  })
})