import { ProfileEditComponent } from './profile-edit.component'

describe('ProfileEditComponent', () => {
  it('should mount', () => {
    cy.mount(ProfileEditComponent)
  })
})