import { NgModule } from '@angular/core';
import { IconsRoutingModule } from './icons-routing.module';

@NgModule({
  declarations: [],
  imports: [
    IconsRoutingModule,
  ]
})
export class IconsModule { }
