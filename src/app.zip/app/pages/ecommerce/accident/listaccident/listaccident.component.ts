import { Component ,OnInit} from '@angular/core';
import { AccidentService } from 'src/app/shared/services/accident.service';
import { Accident } from 'src/app/shared/classes/entities/accident';

import { NgbPaginationConfig } from '@ng-bootstrap/ng-bootstrap';
import { Page } from 'src/app/shared/classes/entities/page';
@Component({
  selector: 'app-listaccident',
  templateUrl: './listaccident.component.html',
  styleUrl: './listaccident.component.css'
})
export class ListaccidentComponent implements OnInit {
  accidents: Accident[] = [];
  page!: Page<Accident>;
  pageSize = 20;
  pageNumber = 1;

  constructor(private accidentService: AccidentService) {
    
  }

  ngOnInit(): void {
    this.loadAccidents();
  }

  loadAccidents(): void {
    this.accidentService.getAllAccidents(this.pageNumber - 1, this.pageSize)
      .subscribe(data => {
        this.page = data;
        this.accidents = data.content;
      });
  }

  onPageChange(page: number): void {
    this.pageNumber = page;
    this.loadAccidents();
  }
}