import { ListaccidentComponent } from './listaccident.component'

describe('ListaccidentComponent', () => {
  it('should mount', () => {
    cy.mount(ListaccidentComponent)
  })
})