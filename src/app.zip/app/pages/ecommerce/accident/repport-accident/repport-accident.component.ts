import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AccidentService } from 'src/app/shared/services/accident.service';
import { Router } from '@angular/router';
import { Accident } from 'src/app/shared/classes/entities/accident';
import { AuthService } from '../../../../shared/services/auth.service';
@Component({
  selector: 'app-repport-accident',
  templateUrl: './repport-accident.component.html',
  styleUrl: './repport-accident.component.css'
})
export class RepportAccidentComponent implements OnInit {
  accidentForm!: FormGroup;
  submitted = false;
  success = false;
  error: string = '';

  constructor(
    private fb: FormBuilder,
    private accidentService: AccidentService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.accidentForm = this.fb.group({
      description: ['', [Validators.required, Validators.maxLength(500)]],
      dateAccident: ['', Validators.required],
      location: ['', Validators.required],
      severity: ['', Validators.required]
    });
  }

  get f() {
    return this.accidentForm.controls;
  }

  onSubmit(): void {
    this.submitted = true;

    if (this.accidentForm.invalid) {
      return;
    }

    const formValue = this.accidentForm.value;

    const accident: Accident = {
      ...formValue,
      livraison: { id: 1 } as any, // à adapter dynamiquement
      livreur: { id: 2 } as any    // à adapter dynamiquement
    };

    this.accidentService.signalerAccident(accident).subscribe({
      next: () => {
        this.success = true;
        setTimeout(() => this.router.navigate(['/ecommerce/listaccidents']), 2000);
      },
      error: (err) => {
        this.error = 'Erreur lors du signalement de l’accident';
        console.error(err);
      }
    });
  }
}