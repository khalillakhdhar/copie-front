import { ReviewComponent } from './review.component'

describe('ReviewComponent', () => {
  it('should mount', () => {
    cy.mount(ReviewComponent)
  })
})