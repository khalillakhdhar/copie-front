import { BouttonActionComponent } from './boutton-action.component'

describe('BouttonActionComponent', () => {
  it('should mount', () => {
    cy.mount(BouttonActionComponent)
  })
})