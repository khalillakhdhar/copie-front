import { SupplierComponent } from './supplier.component'

describe('SupplierComponent', () => {
  it('should mount', () => {
    cy.mount(SupplierComponent)
  })
})