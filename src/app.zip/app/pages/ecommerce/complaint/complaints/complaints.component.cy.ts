import { ComplaintsComponent } from './complaints.component'

describe('ComplaintsComponent', () => {
  it('should mount', () => {
    cy.mount(ComplaintsComponent)
  })
})