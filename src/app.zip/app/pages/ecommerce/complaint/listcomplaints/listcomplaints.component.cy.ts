import { ListcomplaintsComponent } from './listcomplaints.component'

describe('ListcomplaintsComponent', () => {
  it('should mount', () => {
    cy.mount(ListcomplaintsComponent)
  })
})