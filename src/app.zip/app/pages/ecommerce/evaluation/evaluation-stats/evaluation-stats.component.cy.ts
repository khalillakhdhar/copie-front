import { EvaluationStatsComponent } from './evaluation-stats.component'

describe('EvaluationStatsComponent', () => {
  it('should mount', () => {
    cy.mount(EvaluationStatsComponent)
  })
})