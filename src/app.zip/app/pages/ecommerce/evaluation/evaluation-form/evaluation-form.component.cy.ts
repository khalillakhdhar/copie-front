import { EvaluationFormComponent } from './evaluation-form.component'

describe('EvaluationFormComponent', () => {
  it('should mount', () => {
    cy.mount(EvaluationFormComponent)
  })
})