import { Component } from '@angular/core';

@Component({
  selector: 'app-livraison',
  templateUrl: './livraison.component.html',
  styleUrl: './livraison.component.scss'
})
export class LivraisonComponent {

}
