import { MenuItem } from './menu.model';
export const MENU: MenuItem[] = [
    {
        id: 1,
        label: 'MENU', 
        isTitle: true
    },
    {
        id: 2,
        label: 'TABLEAUX DE BORD', 
        icon: 'bx-home-circle',
        subItems: [
            {
                id: 3,
                label: 'TABLEAU DE BORD PAR DÉFAUT', 
                link: '/dashboard',
                parentId: 2
            },
            {
                id: 4,
                label: 'Profile', 
                link: '/profil',
                parentId: 2
            },
             {
                id: 4,
                label: 'Modifier Profile', 
                link: '/profilEdit',
                parentId: 2
            },
            
           
        ]
    },
    {
        id: 7,
        isLayout: true
    },
    {
        id: 8,
        label: 'APPLICATIONS', 
        isTitle: true
    },
    
    

    {
        id: 12,
        label: 'E-COMMERCE', 
        icon: 'bx-store',
        subItems: [
            {
                id: 21,
                label: 'Produits', 
                subItems: [
                    {
                        id: 22,
                        label: 'Ajouter un Produit', 
                        link: '/ecommerce/add-product',
                        parentId: 21 
                    },
                    {
                        id: 23,
                        label: 'Liste des Produits', 
                        link: '/ecommerce/products',
                        parentId: 21
                    },
                  
                ]
            },
            {
                id: 25,
                label: 'Catégories', 
                link: '/ecommerce/categories',
                parentId: 12
            },
            {
                id: 28,
                label: 'Commandes', 
                link: '/ecommerce/orders',
                parentId: 12
            },
            {
                id: 30,
                label: 'Livreurs',
                link :'/ecommerce/supplier'
            },
            {
                id: 33,
                label: 'Clients', 
                link: '/ecommerce/customers',
                    
             
            },
            {
                id: 31,
                label: 'Panier', 
                link: '/ecommerce/cart',
                parentId: 12
            },
            {
                id: 32,
                label: 'Commande', 
                link: '/ecommerce/checkout',
                parentId: 12
            },
        ]
    },

   
  
    {
        id: 37,
        label: 'FACTURES', 
        icon: 'bx-receipt',
        subItems: [
            {
                id: 38,
                label: 'Liste des Factures',
                link: '/invoices/list',
                parentId: 37
            },
          
        ]
    },
    {
        id: 141,
        label: 'RECLAMATIONS', 
        icon: 'bx-chat',
        subItems: [
            {
                id: 143,
                label: 'Passer reclamation', 
                link: '/ecommerce/complaints',
                parentId: 141
            },
            {
                id: 144,
                label: 'Gestion reclamations', 
                link: '/ecommerce/listcomplaints',
                parentId: 141
            },
        ]
    },
    {
        id: 142,
        label: 'ACCIDENTS', 
        icon: 'bx-chat',
        subItems: [
            {
                id: 143,
                label: 'Signaler Accident', 
                link: 'ecommerce/repportAccident',
                parentId: 142
            },
            {
                id: 144,
                label: ' Consulter Accident', 
                link: 'ecommerce/listaccidents',
                parentId: 142
            },
        ]
    },
     
   
    {
        id: 66,
        label: 'PAGES', 
        isTitle: true
    },
    {
        id: 130,
        icon: 'bxs-bar-chart-alt-2',
        label: 'GRAPHIQUES', 
        subItems: [
            {
                id: 131,
                label: 'Apex Charts', 
                link: '/charts/apex',
                parentId: 130
            },
          
        ]
    },
   
    {
        id: 140,
        label: 'Suivre Livraison',
        icon: 'bx-map',
        subItems: [
            {
                id: 142,
                label: 'Carte Leaflet', 
                link: '/maps/leaflet',
                parentId: 140
            },
        ]
    },
    {
        id: 150,
        label: 'Livraison', 
        icon: 'bx-receipt',
        subItems: [
            {
                id: 143,
                label: 'AdminAttribution',
                link: '/livraison/adminAttribution',
                parentId: 150
            },
          
            {
                id: 145,
                label: 'LivreurAcceptRefus',
                link: '/livraison/livreurAcceptRefuse',
                parentId: 150
            },
           
          
        ]
    },
 
    
];

