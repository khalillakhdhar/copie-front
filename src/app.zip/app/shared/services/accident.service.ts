import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Page } from '../classes/entities/page';
import { Observable } from 'rxjs';
import { Accident } from '../classes/entities/accident';
@Injectable({
  providedIn: 'root'
})
export class AccidentService {
  private apiUrl = 'http://localhost:8080/api/accidents';

  constructor(private http: HttpClient) {}

  // Signal a new accident
  signalerAccident(accident: Accident): Observable<Accident> {
    return this.http.post<Accident>(`${this.apiUrl}/signaler`, accident);
  }

  // Get all accidents with pagination
  getAllAccidents(page: number, size: number): Observable<Page<Accident>> {
    const params = new HttpParams() 
      .set('page', page.toString())
      .set('size', size.toString());
    return this.http.get<Page<Accident>>(`${this.apiUrl}/getAllAccident`, { params });
  }
}

