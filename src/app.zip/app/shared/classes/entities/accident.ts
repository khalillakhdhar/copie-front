import { BaseEntity } from "./baseEntity";
import { Delivery } from "./delivery";
import { Supplier } from "./supplier";

export interface Accident extends BaseEntity{
  description: string; 
  dateAccident: string; 
  location: string; 
  severity: string; 
  livraison: Delivery;
  livreur?: Supplier; 
}