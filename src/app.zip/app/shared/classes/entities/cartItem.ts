export interface  CartItem {
  id: number;
  name: string;
  price: number;
  qty: number;
  total: number;
  image: string;
  stock: number;
  
}