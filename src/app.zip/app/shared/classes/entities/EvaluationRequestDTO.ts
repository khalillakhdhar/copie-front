export interface EvaluationRequestDTO {
  note: number;          // ex: 1 à 5
  commentaire?: string;  // optionnel
}