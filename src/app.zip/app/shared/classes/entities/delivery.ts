import { User } from "src/app/store/Authentication/auth.models";
import { Accident } from "./accident";
import { BaseEntity } from "./baseEntity";
import { DeliveryStatus } from "../enums/deliveryStatus.enum";
import { Evaluation } from "./evaluation";
import { Order } from "./order";
import { Supplier } from "./supplier";
export interface Delivery extends BaseEntity {
    adresseLivraison: string;
    dateLivraisonPrevue: string; 
    statut: DeliveryStatus; 
    evaluation?: Evaluation;
    accidents: Accident[]; 
    commande?: Partial<Order>;
    utilisateur?: User; 
    livreur?: Supplier; 
}
