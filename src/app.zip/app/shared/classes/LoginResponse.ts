export interface LoginResponse {
    token: string;
    email: string;
    userId: number;
    roles: string[];
  }
  