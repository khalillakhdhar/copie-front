export enum TypeReclamation {
    Livraison = 'Livraison',
    Facturation = 'Facturation',
    Service_Client = 'Service_Client',
    Accident = 'Accident',
    Autre = 'Autre'
  }