export enum Vehicle {
    Moto = 'MOTO',
    Voiture = 'VOITURE',
    Camionnette = 'CAMIONNETTE'
  }