
export enum TypeOrder{
EnCours = 'enCours',
Confirmee = 'confirmée',
Annulee = 'annulée',
Livree = 'livrée'
}