export enum SupplierStatus {
    Actif = 'ACTIF',
    Inactif = 'INACTIF'
  }