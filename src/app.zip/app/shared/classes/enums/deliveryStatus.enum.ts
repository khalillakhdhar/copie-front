export enum DeliveryStatus {
    EnAttente = 'enAttente',
    Attribuee = 'attribuée',
    EnCours = 'enCours',
    Livree = 'livrée',
    Refusee = 'refusée'
  }