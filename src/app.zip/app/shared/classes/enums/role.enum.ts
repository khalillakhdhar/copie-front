export enum Role {
    Administrateur = 'Administrateur',  
    Client = 'Client',                  
    Livreur = 'Livreur'                 
  }