export interface InvoiceList {
    name: string;
    image?: string;
    title: string;
    id: string;
    date: string;
    amount: string;
}
