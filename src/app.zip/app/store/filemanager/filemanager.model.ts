export interface Filemanager {
    id?: string;
    name?: string;
    date?: string;
    size?: string;
    actions?: string;
}
