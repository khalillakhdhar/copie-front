export interface OrdersModel {
    id?: any;
    name?: string;
    date?: string;
    total?: string;
    status?: string;
    payment_icon?: string;
    payment?: any;
    index?: any;
}

