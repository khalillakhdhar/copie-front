export interface CandidateListModel {
    id: any;
    type: string;
    profile: string;
    name: string;
    position: string;
    location: any;
    price: any;
    tags: Array<{}>;
    active?: any;
}
